# Template LaTeX pour brevet français

Template conforme aux spécifications données par l'inpi : [pdf](https://www.inpi.fr/sites/default/files/formulaire_brevet.pdf)

