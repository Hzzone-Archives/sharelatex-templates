Readme - this file

For Astronomy and Astrophysics
------------------------------
1. Files:
---------
ARAstroBib.sty - Must use package for Astronomy & Astrophysics
Astronomy.bst - Bibliography style file for Astronomy & Astrophysics
natbib.sty - Must use package for Astronomy & Astrophysics (called in package ARAstroBib.sty)
			Available on CTAN
 
2. Usage:
---------
In the .tex file include the following.
\usepackage{ARAstroBib}
\bibliographystyle{Astronomy}

NOTE: natbib package with documentation is available on CTAN.
