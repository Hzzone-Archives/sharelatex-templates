Readme - this file

Fluid Mechanics
---------------
1. Files:
---------
FluidMechanics.bst - Bibliography style file for Fluid Mechanics.
natbib.sty - Must use package for Fluid Mechanics. 
             Available on CTAN.

2. Usage:
---------
In the .tex file include the following.
\usepackage[sort]{natbib}
\bibpunct{(}{)}{,}{a}{}{,}
\bibliographystyle{FluidMechanics}

NOTE: natbib package with documentation is available on CTAN.
