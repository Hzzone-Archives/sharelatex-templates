LaTeX templates
December 7, 2012

For use with Photonics Research


See Optics InfoBase Author page to obtain templates for other journals: 
http://www.opticsinfobase.org/author/author.cfm

1. osajnl2.sty (new style file, replaces osajnl.sty)

2. osajnl2.rtx (new REVTeX style file, replaces osajnl.rtx)

3. style.tex: style guide & template for all but OL and OpEx

4. temp.tex: template for all but OL and OpEx

5. revtex-temp.tex: template with sample REVTeX feature to automate author/affiliation block

6. osajnl.bst: BibTeX style file for OSA journals


This work may be distributed and/or modified under the conditions of the LaTeX Project Public License, either version 1.3 of this license or any later version.The latest version of this license is in http://www.latex-project.org/lppl.txt and version 1.3 or later is part of all distributions of LaTeX version 2005/12/01 or later.

