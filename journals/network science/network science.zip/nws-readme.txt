% README.TXT for nws.cls
% v1.0 released 14th June 2012
% Copyright 2012 Cambridge University Press
% This software may only be used in the preparation of journal articles
% or books or parts of books to be published by Cambridge University Press.
% Any other use constitutes an infringement of copyright.
%
% The files for nws.cls are contained within the folder NWS.
%
% This folder contains the following files
%
%   nws.cls        the class file
%   nwsguide.tex   author guide source files
%   nws.bst        NWS BibTeX style file
%   nwsguide.pdf   authors' guide
%   natbib.sty     for bibliography
%   mathptmx.sty   style for fonts for the guide#
%   amsfonts.sty   style for AMS fonts

