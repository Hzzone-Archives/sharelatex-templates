
The file amspaper.pdf (or amspaper2col.pdf) contains information about use of the AMS LaTeX template

For questions/problems related to submitting your LaTeX manuscript to the AMS see the AMS LaTeX FAQ Page:
http://www.ametsoc.org/pubs/journals/LaTeXFAQ.html
or contact:
latex@ametsoc.org