ACM Transactions and Journals (small trim Size) 
-----------------------------------------------------------------

The following files are available in the acmlarge.zip archive:

acmsmall.cls	     			- This is V1.8 of the LaTeX2e class file for the 'acmsmall template/format'
ACM-Reference-Format-Journals.bst	- This is the bibliography style file for the New ACM Reference Format (March 2012)
acmsmall-sample-bibfile.bib		- This is the bibliography database file
acmsmall-guide.pdf			- This is a PDF of the "author guidelines' for the acmlsmall template
acm-update.pdf			        - This is a PDF of documentation updates
acmsmall-sample.pdf			- This is a PDF file showing what YOU should obtain
					  when YOU compile the sample source .tex file

acmsmall-sample.tex			- the revised (v2) source sample .tex file 
acmsmall-sample.bbl			- the bbl file as a result of 'BibTeX'ing 
acmsmall-mouse.eps			- Graphics file used in sample
acmsmall-mouse.pdf			- a graphics file in PDF format, (compatible with pdflatex)
readme.txt				- This file!

Happy (La)TeXing!!!

