----------------------------------------------------------------
beilstein --- Support for submissions to the ``Beilstein Journal
of Nanotechnology'' published by the Beilstein-Institut
for the Advancement of Chemical Sciences
E-mail: journals-support@beilstein-institut.de
Released under the LaTeX Project Public License v1.3c or later
See http://www.latex-project.org/lppl.txt
----------------------------------------------------------------

The Beilstein bundle provides a LaTeX class file and a BibTeX
style file in accordance with the requirements of submissions to
the Beilstein Journal of Nanotechnology. Although the
files can be used for any kind of document, they have only been
designed and tested to be suitable for submission to the Beilstein Journal of Nanotechnology.

