PASA Author Template (CUP Journals)
------------------------------------------

The following files are available in pasa.zip archive:

pasa.cls			- This is the LaTeX2e class file for PASA template
aas_macros.sty      - LaTeX package (contain abbreviations of various journal names)
pasa-auguide.pdf	- This is PDF of Author Guide for PASA template
pasa-sample.pdf		- This is PDF file of sample LaTeX document for PASA template
pasa-sample.tex		- This is file of sample LaTeX document for PASA template
apj.bst				- This is bibliography style file
pasa-mnras.bst      - This is bibliography style file
1r_lamboo_notes.bib - Sample BIB file (Bibliography Database File)
fpo.eps				- Graphics file used in sample EPS format
fpo.pdf				- Graphics file used in sample PDF format


Happy TeXing!!!
Aptara
