Files in this package:

00readme.txt = The file you are just reading
informs3.cls = current INFORMS journal class
Management-Science-template.tex = template 
Management-Science-template.pdf = PDF to visualize the above file
natbib.sty = natbib style, version for which the next file (.bst) is derived
ormsv080.bst = INFORMS BiBTeX style
Sample-Figure.eps = sample figure used in the template
Author-Year-Bib-Sample.pdf = detailed samp[le about the INFORMS style in bibliographies
Style-Instructions.pdf = detailed instruction about the INFORMS house style


