April 5, 2012

Instructions added for Optics Letters.

Placeholder DOI added below OCIS codes.

October 5, 2012 OSA - The Optical Society

This is a Beta release of OSA template and style files to run with REVTeX4-1.
Authors may use this template to prepare manuscripts in two columns for submission to OSA's journals.
Applied Optics, JOSA A, and JOSA B. A two-column manuscript with embedded figures and tables is suitable for submission.

See OSA's Optics InfoBase Author page for information on submission to other journals.

Included in this release:
- osa-revtex4-1.tex
- osa-revtex4-1.pdf
- osajnl4-1.rtx
- osajnl10pt4-1.rtx
- osajnl11pt4-1.rtx
- osajnl12pt4-1.rtx


Send feedback to beta@osa.org

For more information on REVTeX and OSA submissions see

- https://authors.aps.org/revtex4/
- http://www.opticsinfobase.org/submit/style/jrnls_style.cfm
