HOW TO USE THIS TEMPLATE

(1) Print and read the final output PDF file, namely
"mainthesisUVIC.pdf".

(2) Download and install the appropriate Latex package for Windows or Mac or Unix/Linux.

(3) Use the appropriate Latex package to compile the thesis
template starting at the top (root) file in the top directory,
namely "mainthesisUVIC.tex" in the folder "ThesisTemplateUVIC2009".