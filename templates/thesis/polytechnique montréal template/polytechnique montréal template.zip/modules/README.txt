Plusieurs logiciels permettant la rédaction de documents LaTeX peuvent
télécharger automatiquement les modules qui manquent au moment de la compilation.

Dans le cas ou votre logiciel ne peut le faire, recopiez les fichiers
.sty dans le répertoire dans lequel le document LaTeX est compilé.
