#!/bin/bash
git checkout master
git merge dev
git checkout dev-en
git merge master
git checkout master-en
git merge dev-en
git checkout bibtex
git merge master
git checkout ms-geo-dev
git merge master
git checkout ms-geo
git merge ms-geo-dev
git checkout ms-poo-dev
git merge master
git checkout ms-poo
git merge ms-poo-dev
