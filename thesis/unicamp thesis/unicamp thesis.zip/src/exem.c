#include <stdlib.h>
#include <stdio.h>

int main(){
    printf("Hello.\n");

    int i;
    int j;

    for(i = 0; i < 10; i ++){
        printf("%d", i);
    }
}
