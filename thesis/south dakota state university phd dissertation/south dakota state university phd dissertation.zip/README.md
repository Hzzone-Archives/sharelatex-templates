# South Dakota State University Dissertation Template

This template was successfully used to create a South Dakota
State University dissertation in 2015. 

## Directions

1. In main.tex, specify your title, name, major, advisor and dept. head
1. In signature.tex, change the department name and alter the hspace to line up the word 'Date'
1. In main.tex, changes the options for the package **biblatex**, this will change the style of the references, currently it is set to IEEE style
1. Write your dissertation!
