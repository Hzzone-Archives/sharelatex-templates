Modelo de Dissertação e Teses em Latex
=================

Modelo de dissertação e teses em latex. Para alternar o documentclass entre:

1. `\documentclass[diss]{dcc-nce}` para dissertação
2. `\documentclass[tese]{dcc-nce}` para tese
