# masters-thesis

This repo contains the template in IIT K Thesis format.


prelude.tex -- Add your personal information in this file.
citation.bib -- Add the Bibtex of the refered work.
related.tex , conclusions.tex , application.tex , intro.tex , technical.tex -- They correspond to different chapters in your Thesis.
thesis.tex  -- It is the main file. Puts all the tex files as chapter in your Thesis. 


For sharelatex users: change the compiler to XeLatex or LuaLatex.
others: use makefile




This repo has been forked from https://github.com/sid0/masters-thesis
