Below are some common formatting problems with solutions.
Fri Jan 11 15:36:58 CST 2008, submitted by Darin Brezeale 
Wed Jul 20 10:58:01 CDT 2011, updated by Darin Brezeale
Mon Aug 11                    updated by W. Alan Davis

The LaTeX template consists of a set of .tex files for the various sample
chapters as well a style file (utathesis.sty) that sets format values.  There
is also a file called utaexample.tex that pulls the individual chapter files
together to form the entire dissertation. 

LaTeX requires TeX which would normally be downloaded together. A LaTeX (or
TeX) files is created using a standard editor. The file name could be
foo.tex. Certain editors like emacs will give color signals if something is
correct or in error such as unbalanced braces.  Compiling the file is done by
	latex foo.tex

This produces a variety of files, one of which is foo.dvi.  Viewing this file
with:
	xdvi foo.dvi
This will show there are no references and the equation numbers have ? marks.
To get the references:
    	bibtex foo.aux
To get the equation numbers correct, recompile twice.
       latex foo.tex
       latex foo.tex

So in summary, the process is:
       latex foo.tex
       bibtex foo.aux
       latex foo.tex
       latex foo.tex
    	
Some versions may call bibtex automatically, so all that would be needed is
to call latex foo.tex twice.  

Some points often overlooked in writing mathematical equations and
functions. First of all, variables are always italics and constants or
descriptions are standard vertical Roman font. Thus in writing a variable
such as the electron and hole mobilities where the subscript is a name, and not
a variable, then $ \mu_{\rm n}$ and $\mu_{\rm p}$ are correct while $\mu_n$
and $\mu_p$ are incorrect.  This also applies to integrals and
derivatives. The ``d'' is not a variable so it should not be italics. Also, in
an integral a small additional space should be given between the differental
and the integrand.  Thus $\int f(x) \ {\rm d} x$ is correct while $\int f(x)
dx$ is incorrect in a couple of ways. The coding for this can be seen in
looking at the chap1.tex file.

1)  The most common formatting problem is that the bottom margin of all pages
is not between 1.25 and 1.5 inches.  The left and right margins are not
between 1.25 and 1.5 inches.  This is true regardless of whether you are using
LaTeX on Linux or Windows. 

Solution:  When using LaTeX on a Linux operating system, one way to generate PDF documents is to use
	dvipdf utaexample.tex
The problem with this is that dvipdf defaults to a paper size of A4, which is
longer and narrower than 8.5" by 11".  This affects the left, right, and
bottom margins.  To produce a document with the correct dimensions, in Linux
first generate the DVI file.  Convert this file to postscript, then convert
the postscript file to PDF using the following two commands: 

        dvips -t letter -Ppdf -G0 utaexample.dvi
        ps2pdf utaexample.ps
or with a more recent converter
	ps2pdf14 utaexample.ps utaexample.pdf

If you are using LaTeX on Windows, you may (depending on how your environment is configured) be able to open a command window and type 

       dvips -t letter -Ppdf -G0 utaexample.dvi
       ps2pdf utaexample.ps

to generate a PDF with the correct dimensions.


2) Titles in the front matter and text longer than one line are appearing
double-spaced in the front matter, but they should be single spaced. 

Solution: The sample document included with the template show examples of this
and how to correct them.  Basically, at the point where you have the section
title, caption title, etc., you need to create two versions of it.  One
version will appear at that location in the document, the other version will
appear in the table of contents and will include formatting commands
specifically for the table of contents.  YOU DO NOT HAVE TO CHANGE THE
TEMPLATE ITSELF FOR THIS PROBLEM. 



3)  You are submitting electronically, so you should not include a signature page.

Solution:  Simply remove the reference to the signature page in the file
utaexample.tex and move the reference to the title page so that it occurs
before the copyright page. 

REFERENCE

H. Kopka and P. W. Daly, "Guide to LaTeX", Fourth Ed., Addison-Wesley: Boston,
2004. 
